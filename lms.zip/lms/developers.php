<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3">
										<center>
										  <hr>
										<p>Name: Ashish Sharma </p>
										<p>Address: MORADABAD</p>
										<p>Email: ashish.039277@tmu.ac.in.</p>
										<p>&nbsp;</p>
										</center>
								</div>
                                <div class="span3">
															<center>
															  <hr>
																				<p>Name: Harsh Gaur </p>

										                                        <p>Address: MORADABAD</p>
										<p>Email: harshgaur5087@gmail.com </p>
										<p>&nbsp;</p>
								</center>
								</div>
                                <div class="span3">
								  <center>
															  <hr>
												<p>Name: Harshita</p>
										        <p>Address: MORADABAD </p>
							        <p>Email:harshita2585@gmail.com </p>
						          </center>
								</div>
                                <div class="span3">
															<center>
															  <hr>
												<p>&nbsp;</p>
										        <p>&nbsp;</p>
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>