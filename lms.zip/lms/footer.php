<center>
		<footer>
		
		<p> Smart Learning Solution Copyright - 2024</p>
			<p>Programmed by: [Ashish]-[Harshita]-[Harsh]</p>
		
		</footer>
</center>

